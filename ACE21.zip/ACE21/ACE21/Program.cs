﻿using System;
using System.Collections.Generic;
class ACE21
{
    static void Main(string[] args)
    {
        Random random = new Random();
        List<string> playerHand = new List<string>();
        List<string> dealerHand = new List<string>();

        Console.WriteLine("Welcome to Blackjack!");

        
        playerHand.Add(DrawCard(random));
        playerHand.Add(DrawCard(random));
        dealerHand.Add(DrawCard(random));
        dealerHand.Add(DrawCard(random));

        
        while (true)
        {
            Console.WriteLine($"\nYour hand: {string.Join(", ", playerHand)} (Total: {CalculateHand(playerHand)})");
            Console.WriteLine($"Dealer's visible card: {dealerHand[0]}");

            if (CalculateHand(playerHand) == 21)
            {
                Console.WriteLine("ACE! You win!");
                return;
            }

            Console.Write("Do you want to (h)it or (s)tand? ");
            char choice = Console.ReadLine().ToLower()[0];

            if (choice == 'h')
            {
                playerHand.Add(DrawCard(random));
                if (CalculateHand(playerHand) > 21)
                {
                    Console.WriteLine($"Your hand: {string.Join(", ", playerHand)} (Total: {CalculateHand(playerHand)})");
                    Console.WriteLine("Bust! You lose!");
                    return;
                }
            }
            else if (choice == 's')
            {
                break;
            }
        }

        
        while (CalculateHand(dealerHand) < 17)
        {
            dealerHand.Add(DrawCard(random));
        }

        Console.WriteLine($"\nDealer's hand: {string.Join(", ", dealerHand)} (Total: {CalculateHand(dealerHand)})");

        int playerTotal = CalculateHand(playerHand);
        int dealerTotal = CalculateHand(dealerHand);

        if (dealerTotal > 21 || playerTotal > dealerTotal)
        {
            Console.WriteLine("You win!");
        }
        else if (playerTotal == dealerTotal)
        {
            Console.WriteLine("It's a tie!");
        }
        else
        {
            Console.WriteLine("You lose!");
        }
    }

    static string DrawCard(Random random)
    {
        int card = random.Next(1, 14); 
        return card switch
        {
            1 => "A", 
            11 => "J", 
            12 => "Q", 
            13 => "K", 
            _ => card.ToString() 
        };
    }

    static int CalculateHand(List<string> hand)
    {
        int total = 0;
        int aces = 0;

        foreach (string card in hand)
        {
            if (card == "A")
            {
                aces++;
                total += 11;
            }
            else if (card == "J" || card == "Q" || card == "K")
            {
                total += 10;
            }
            else
            {
                total += int.Parse(card);
            }
        }

        while (total > 21 && aces > 0)
        {
            total -= 10;
            aces--;
        }

        return total;
    }
}
